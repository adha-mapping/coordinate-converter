import { convertRSO } from './converters/rso_to_wgs84.js';
import { convertUTM } from './converters/utm_to_wgs84.js';
import { convertCassini } from './converters/cassini_to_wgs84.js';

document.getElementById('convertForm').addEventListener('submit', function (e) {
  e.preventDefault();
  const x = parseFloat(document.getElementById('x').value);
  const y = parseFloat(document.getElementById('y').value);
  const z = parseFloat(document.getElementById('z').value);
  const inputSystem = document.getElementById('inputSystem').value;

  let result;
  if (inputSystem === 'rso') result = convertRSO(x, y, z);
  if (inputSystem === 'utm') result = convertUTM(x, y, z);
  if (inputSystem === 'cassini') result = convertCassini(x, y, z);

  document.getElementById('lat').textContent = result.lat;
  document.getElementById('lon').textContent = result.lon;
  document.getElementById('height').textContent = result.height;

  L.marker([result.lat, result.lon]).addTo(map);
  map.setView([result.lat, result.lon], 13);
});

document.getElementById('exportBtn').addEventListener('click', function () {
  const lat = document.getElementById('lat').textContent;
  const lon = document.getElementById('lon').textContent;
  const height = document.getElementById('height').textContent;

  const csvContent = 'Latitude,Longitude,Ellipsoidal Height\n' +
    `${lat},${lon},${height}\n`;

  const blob = new Blob([csvContent], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'converted_coordinates.csv';
  a.click();
  URL.revokeObjectURL(url);
});

const map = L.map('map').setView([0, 0], 2);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: 'Map data © OpenStreetMap contributors'
}).addTo(map);